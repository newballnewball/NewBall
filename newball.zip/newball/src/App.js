import { useEffect, useState } from "react";
import { onAuthStateChanged } from "firebase/auth";
import { auth } from "./firebase";
import AuthScreen from "./components/AuthScreen";
import MainApp from "./components/MainApp";

export default function App() {
  const [user, setUser] = useState(undefined); // undefined = loading
  const [invitedBy, setInvitedBy] = useState(null);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const ref = params.get("ref");
    if (ref) setInvitedBy(ref);
    return onAuthStateChanged(auth, u => setUser(u || null));
  }, []);

  if (user === undefined) {
    return (
      <div style={{ background:"#0a0a0f", minHeight:"100vh", display:"flex", alignItems:"center", justifyContent:"center" }}>
        <div style={{ fontSize:36 }}>🎱</div>
      </div>
    );
  }

  if (!user) return <AuthScreen invitedBy={invitedBy} />;
  return <MainApp user={user} />;
}
