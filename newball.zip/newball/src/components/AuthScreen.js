import { useState } from "react";
import {
  signInWithPopup,
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  updateProfile,
} from "firebase/auth";
import { doc, setDoc, getDoc, serverTimestamp } from "firebase/firestore";
import { auth, db, googleProvider, appleProvider, ADMIN_EMAIL } from "../firebase";

async function ensureUserDoc(user, extraData = {}) {
  const ref = doc(db, "users", user.uid);
  const snap = await getDoc(ref);
  if (!snap.exists()) {
    await setDoc(ref, {
      uid: user.uid,
      name: user.displayName || extraData.name || "Member",
      email: user.email,
      photoURL: user.photoURL || null,
      wish: "",
      paid: false,
      streak: 0,
      isAdmin: user.email === ADMIN_EMAIL,
      joinedAt: serverTimestamp(),
      invitedBy: extraData.invitedBy || null,
      ...extraData,
    });
  }
}

export default function AuthScreen({ invitedBy }) {
  const [mode, setMode] = useState("login"); // login | signup
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const handle = async (fn) => {
    setError("");
    setLoading(true);
    try { await fn(); }
    catch (e) { setError(e.message.replace("Firebase: ", "").replace(/\(auth.*\)\.?/, "")); }
    finally { setLoading(false); }
  };

  const loginGoogle = () => handle(async () => {
    const result = await signInWithPopup(auth, googleProvider);
    await ensureUserDoc(result.user, { invitedBy });
  });

  const loginApple = () => handle(async () => {
    const result = await signInWithPopup(auth, appleProvider);
    await ensureUserDoc(result.user, { invitedBy });
  });

  const loginEmail = () => handle(async () => {
    if (mode === "signup") {
      const result = await createUserWithEmailAndPassword(auth, email, password);
      await updateProfile(result.user, { displayName: name });
      await ensureUserDoc(result.user, { name, invitedBy });
    } else {
      await signInWithEmailAndPassword(auth, email, password);
    }
  });

  return (
    <div style={styles.outer}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@300;400;500;600;700&family=Fraunces:ital,opsz,wght@0,9..144,700;1,9..144,300&display=swap');
        * { box-sizing: border-box; margin: 0; padding: 0; }
        input { outline: none; }
        input::placeholder { color: rgba(255,255,255,0.25); }
        @keyframes fade-up { from{opacity:0;transform:translateY(16px)} to{opacity:1;transform:translateY(0)} }
        @keyframes glow { 0%,100%{box-shadow:0 0 24px rgba(168,85,247,0.35)} 50%{box-shadow:0 0 40px rgba(168,85,247,0.6)} }
      `}</style>

      {/* BG orbs */}
      <div style={{ position:"fixed",top:-80,right:-80,width:300,height:300,borderRadius:"50%",background:"radial-gradient(circle,rgba(168,85,247,0.2) 0%,transparent 70%)",pointerEvents:"none" }}/>
      <div style={{ position:"fixed",bottom:-60,left:-60,width:240,height:240,borderRadius:"50%",background:"radial-gradient(circle,rgba(236,72,153,0.15) 0%,transparent 70%)",pointerEvents:"none" }}/>

      <div style={styles.card}>
        {/* Logo */}
        <div style={{ textAlign:"center", marginBottom:32, animation:"fade-up 0.4s ease" }}>
          <div style={{ fontSize:48, marginBottom:8 }}>🎱</div>
          <div style={{ fontFamily:"'Fraunces',serif", fontSize:34, fontWeight:700, color:"#fff", letterSpacing:"-1px" }}>
            New Ball
          </div>
          <div style={{ fontSize:13, color:"rgba(255,255,255,0.35)", marginTop:6 }}>
            everybody chips in · one person wins
          </div>
          {invitedBy && (
            <div style={{ marginTop:12, fontSize:13, color:"#c084fc", background:"rgba(192,132,252,0.1)", border:"1px solid rgba(192,132,252,0.2)", borderRadius:20, padding:"6px 14px", display:"inline-block" }}>
              ✨ You were invited to join
            </div>
          )}
        </div>

        {/* Social buttons */}
        <div style={{ display:"flex", flexDirection:"column", gap:10, marginBottom:20, animation:"fade-up 0.4s ease 0.1s both" }}>
          <button onClick={loginGoogle} disabled={loading} style={styles.socialBtn}>
            <svg width="18" height="18" viewBox="0 0 48 48"><path fill="#FFC107" d="M43.6 20H24v8h11.3C33.6 33.1 29.3 36 24 36c-6.6 0-12-5.4-12-12s5.4-12 12-12c3 0 5.8 1.1 7.9 3l5.7-5.7C34 6.5 29.3 4 24 4 12.9 4 4 12.9 4 24s8.9 20 20 20c11 0 19.7-8 19.7-20 0-1.3-.1-2.7-.1-4z"/><path fill="#FF3D00" d="M6.3 14.7l6.6 4.8C14.5 16 19 12 24 12c3 0 5.8 1.1 7.9 3l5.7-5.7C34 6.5 29.3 4 24 4c-7.7 0-14.3 4.3-17.7 10.7z"/><path fill="#4CAF50" d="M24 44c5.2 0 9.9-1.9 13.5-5l-6.2-5.2C29.4 35.6 26.8 36 24 36c-5.2 0-9.7-3-11.7-7.3l-6.5 5C9.5 39.6 16.2 44 24 44z"/><path fill="#1976D2" d="M43.6 20H24v8h11.3c-.9 2.5-2.6 4.6-4.8 6l6.2 5.2C40.9 36.2 44 30.5 44 24c0-1.3-.1-2.7-.4-4z"/></svg>
            Continue with Google
          </button>
          <button onClick={loginApple} disabled={loading} style={{ ...styles.socialBtn, background:"rgba(255,255,255,0.06)" }}>
            <svg width="18" height="18" viewBox="0 0 24 24" fill="white"><path d="M18.71 19.5c-.83 1.24-1.71 2.45-3.05 2.47-1.34.03-1.77-.79-3.29-.79-1.53 0-2 .77-3.27.82-1.31.05-2.3-1.32-3.14-2.53C4.25 17 2.94 12.45 4.7 9.39c.87-1.52 2.43-2.48 4.12-2.51 1.28-.02 2.5.87 3.29.87.78 0 2.26-1.07 3.8-.91.65.03 2.47.26 3.64 1.98-.09.06-2.17 1.28-2.15 3.81.03 3.02 2.65 4.03 2.68 4.04-.03.07-.42 1.44-1.38 2.83M13 3.5c.73-.83 1.94-1.46 2.94-1.5.13 1.17-.34 2.35-1.04 3.19-.69.85-1.83 1.51-2.95 1.42-.15-1.15.41-2.35 1.05-3.11z"/></svg>
            Continue with Apple
          </button>
        </div>

        {/* Divider */}
        <div style={{ display:"flex", alignItems:"center", gap:10, marginBottom:20, animation:"fade-up 0.4s ease 0.2s both" }}>
          <div style={{ flex:1, height:1, background:"rgba(255,255,255,0.08)" }}/>
          <div style={{ fontSize:12, color:"rgba(255,255,255,0.25)" }}>or</div>
          <div style={{ flex:1, height:1, background:"rgba(255,255,255,0.08)" }}/>
        </div>

        {/* Email form */}
        <div style={{ display:"flex", flexDirection:"column", gap:10, animation:"fade-up 0.4s ease 0.3s both" }}>
          {mode === "signup" && (
            <input
              placeholder="Your name"
              value={name}
              onChange={e => setName(e.target.value)}
              style={styles.input}
            />
          )}
          <input
            placeholder="Email"
            type="email"
            value={email}
            onChange={e => setEmail(e.target.value)}
            style={styles.input}
          />
          <input
            placeholder="Password"
            type="password"
            value={password}
            onChange={e => setPassword(e.target.value)}
            style={styles.input}
          />
          {error && <div style={{ fontSize:12, color:"#f87171", textAlign:"center" }}>{error}</div>}
          <button onClick={loginEmail} disabled={loading} style={styles.primaryBtn}>
            {loading ? "..." : mode === "signup" ? "Create account" : "Sign in"}
          </button>
        </div>

        <div style={{ textAlign:"center", marginTop:20, fontSize:13, color:"rgba(255,255,255,0.3)", animation:"fade-up 0.4s ease 0.4s both" }}>
          {mode === "login" ? (
            <>Don't have an account? <span onClick={() => setMode("signup")} style={{ color:"#c084fc", cursor:"pointer" }}>Sign up</span></>
          ) : (
            <>Already have an account? <span onClick={() => setMode("login")} style={{ color:"#c084fc", cursor:"pointer" }}>Sign in</span></>
          )}
        </div>
      </div>
    </div>
  );
}

const styles = {
  outer: {
    fontFamily:"'DM Sans',sans-serif",
    background:"#0a0a0f",
    minHeight:"100vh",
    display:"flex",
    alignItems:"center",
    justifyContent:"center",
    padding:"20px",
  },
  card: {
    width:"100%",
    maxWidth:380,
    padding:"36px 28px",
  },
  socialBtn: {
    width:"100%",
    padding:"13px",
    background:"rgba(255,255,255,0.05)",
    border:"1px solid rgba(255,255,255,0.1)",
    borderRadius:12,
    color:"#fff",
    fontSize:14,
    fontWeight:500,
    cursor:"pointer",
    display:"flex",
    alignItems:"center",
    justifyContent:"center",
    gap:10,
    fontFamily:"inherit",
    transition:"all 0.15s",
  },
  input: {
    width:"100%",
    padding:"13px 16px",
    background:"rgba(255,255,255,0.05)",
    border:"1px solid rgba(255,255,255,0.1)",
    borderRadius:12,
    color:"#fff",
    fontSize:14,
    fontFamily:"inherit",
  },
  primaryBtn: {
    width:"100%",
    padding:"14px",
    background:"linear-gradient(135deg,#7c3aed,#ec4899)",
    border:"none",
    borderRadius:12,
    color:"#fff",
    fontSize:15,
    fontWeight:700,
    cursor:"pointer",
    fontFamily:"inherit",
    marginTop:4,
    animation:"glow 3s ease infinite",
  },
};
