import { useState, useEffect, useRef } from "react";
import {
  collection, doc, onSnapshot, updateDoc, query,
  orderBy, addDoc, serverTimestamp, getDoc, getDocs
} from "firebase/firestore";
import { signOut } from "firebase/auth";
import { db, ADMIN_EMAIL } from "../firebase";

function useCountdown(target) {
  const [t, setT] = useState({ d:0,h:0,m:0,s:0 });
  useEffect(() => {
    const tick = () => {
      const diff = new Date(target) - Date.now();
      if (diff <= 0) return setT({ d:0,h:0,m:0,s:0 });
      setT({ d:Math.floor(diff/86400000), h:Math.floor(diff%86400000/3600000), m:Math.floor(diff%3600000/60000), s:Math.floor(diff%60000/1000) });
    };
    tick(); const id = setInterval(tick,1000); return ()=>clearInterval(id);
  },[target]);
  return t;
}

function Tick({ val, label }) {
  return (
    <div style={{ flex:1, textAlign:"center" }}>
      <div style={{ background:"rgba(255,255,255,0.07)", border:"1px solid rgba(255,255,255,0.1)", borderRadius:10, padding:"10px 4px", fontFamily:"monospace", fontSize:26, fontWeight:700, color:"#fff", lineHeight:1 }}>
        {String(val).padStart(2,"0")}
      </div>
      <div style={{ fontSize:10, color:"rgba(255,255,255,0.35)", marginTop:5, textTransform:"uppercase", letterSpacing:"0.12em" }}>{label}</div>
    </div>
  );
}

export default function MainApp({ user }) {
  const [tab, setTab] = useState("home");
  const [members, setMembers] = useState([]);
  const [myData, setMyData] = useState(null);
  const [wish, setWish] = useState("");
  const [wishSaved, setWishSaved] = useState(false);
  const [likes, setLikes] = useState({});
  const [confetti, setConfetti] = useState([]);
  const [referCopied, setReferCopied] = useState(false);
  const [recentJoin, setRecentJoin] = useState(null);
  const [adminDrawing, setAdminDrawing] = useState(false);
  const [drawWinner, setDrawWinner] = useState(null);
  const isAdmin = user.email === ADMIN_EMAIL;
  const cd = useCountdown("2026-05-01T20:00:00");
  const appUrl = window.location.origin;

  // Listen to all members
  useEffect(() => {
    const q = query(collection(db, "users"), orderBy("joinedAt", "asc"));
    return onSnapshot(q, snap => {
      const data = snap.docs.map(d => ({ id: d.id, ...d.data() }));
      setMembers(data);
      // detect newest non-self member
      const others = data.filter(m => m.uid !== user.uid);
      if (others.length) setRecentJoin(others[others.length-1].name);
    });
  }, [user.uid]);

  // Listen to own doc
  useEffect(() => {
    return onSnapshot(doc(db, "users", user.uid), snap => {
      if (snap.exists()) {
        const d = snap.data();
        setMyData(d);
        setWish(d.wish || "");
        setLikes(d.likes || {});
      }
    });
  }, [user.uid]);

  const paidMembers = members.filter(m => m.paid);
  const pot = paidMembers.length;
  const odds = members.length > 0 ? ((1/Math.max(pot,1))*100).toFixed(1) : "0.0";

  const saveWish = async () => {
    if (!wish.trim()) return;
    await updateDoc(doc(db, "users", user.uid), { wish: wish.trim() });
    setWishSaved(true);
    setTimeout(() => setWishSaved(false), 2500);
  };

  const toggleLike = async (memberId) => {
    const newLikes = { ...likes, [memberId]: !likes[memberId] };
    setLikes(newLikes);
    await updateDoc(doc(db, "users", user.uid), { likes: newLikes });
  };

  const getLikeCount = (memberId) => {
    return members.filter(m => m.likes && m.likes[memberId]).length;
  };

  const markPaid = async () => {
    await updateDoc(doc(db, "users", user.uid), { paid: true, streak: (myData?.streak || 0) + 1 });
  };

  const runDraw = async () => {
    if (!isAdmin || paidMembers.length === 0) return;
    setAdminDrawing(true);
    const winner = paidMembers[Math.floor(Math.random() * paidMembers.length)];
    setDrawWinner(winner);
    // Save to history
    await addDoc(collection(db, "history"), {
      winnerId: winner.uid,
      winnerName: winner.name,
      winnerWish: winner.wish || "",
      amount: pot,
      members: paidMembers.length,
      drawnAt: serverTimestamp(),
      month: new Date().toLocaleString("default", { month:"long", year:"numeric" }),
    });
    // Reset all paid
    const all = await getDocs(collection(db, "users"));
    await Promise.all(all.docs.map(d => updateDoc(d.ref, { paid: false })));
    spawnConfetti();
    setAdminDrawing(false);
  };

  const copyInvite = () => {
    const link = `${appUrl}?ref=${user.uid}`;
    navigator.clipboard.writeText(link).catch(() => {});
    setReferCopied(true);
    setTimeout(() => setReferCopied(false), 2500);
  };

  const spawnConfetti = () => {
    const cols = ["#c084fc","#f472b6","#fb923c","#facc15","#34d399","#60a5fa"];
    setConfetti(Array.from({length:55},(_,i)=>({ id:i, x:Math.random()*100, delay:Math.random()*0.9, size:5+Math.random()*8, rot:Math.random()*360, color:cols[i%cols.length], circle:Math.random()>0.4 })));
    setTimeout(()=>setConfetti([]),4000);
  };

  const sortedMembers = [...members].sort((a,b) => getLikeCount(b.uid) - getLikeCount(a.uid));

  return (
    <div style={{ fontFamily:"'DM Sans',sans-serif", background:"#0a0a0f", minHeight:"100vh", maxWidth:430, margin:"0 auto", display:"flex", flexDirection:"column", color:"#fff", position:"relative" }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@300;400;500;600;700&family=Fraunces:ital,opsz,wght@0,9..144,700;1,9..144,300&display=swap');
        * { box-sizing:border-box; }
        @keyframes fall { 0%{transform:translateY(-10px) rotate(0deg);opacity:1} 100%{transform:translateY(110vh) rotate(900deg);opacity:0} }
        @keyframes fade-up { from{opacity:0;transform:translateY(10px)} to{opacity:1;transform:translateY(0)} }
        @keyframes glow-pulse { 0%,100%{box-shadow:0 0 20px rgba(168,85,247,0.3)} 50%{box-shadow:0 0 40px rgba(168,85,247,0.55)} }
        @keyframes bounce-in { 0%{transform:scale(0.6);opacity:0} 65%{transform:scale(1.08)} 100%{transform:scale(1);opacity:1} }
        .tab-btn { transition:all 0.15s; border:none; cursor:pointer; background:transparent; }
        .btn { transition:all 0.15s; cursor:pointer; border:none; }
        .btn:hover { opacity:0.88; }
        .btn:active { transform:scale(0.97); }
        ::-webkit-scrollbar { width:0; }
        input,textarea { outline:none; }
        input::placeholder,textarea::placeholder { color:rgba(255,255,255,0.22); }
      `}</style>

      {confetti.map(p=>(
        <div key={p.id} style={{ position:"fixed",top:-10,left:`${p.x}%`,width:p.size,height:p.circle?p.size:p.size*0.45,background:p.color,borderRadius:p.circle?"50%":"2px",animation:`fall 3.4s ease-in forwards`,animationDelay:`${p.delay}s`,zIndex:9999,pointerEvents:"none",transform:`rotate(${p.rot}deg)` }}/>
      ))}

      {/* HEADER */}
      <div style={{ background:"linear-gradient(160deg,#1a0533 0%,#180a2e 45%,#0a0a0f 100%)", padding:"22px 20px 26px", position:"relative", overflow:"hidden" }}>
        <div style={{ position:"absolute",top:-60,right:-60,width:220,height:220,borderRadius:"50%",background:"radial-gradient(circle,rgba(168,85,247,0.22) 0%,transparent 70%)",pointerEvents:"none" }}/>
        <div style={{ position:"absolute",bottom:-30,left:-40,width:180,height:180,borderRadius:"50%",background:"radial-gradient(circle,rgba(236,72,153,0.15) 0%,transparent 70%)",pointerEvents:"none" }}/>

        <div style={{ display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:20,position:"relative" }}>
          <div>
            <div style={{ fontFamily:"'Fraunces',serif",fontSize:30,fontWeight:700,letterSpacing:"-0.5px",lineHeight:1 }}>🎱 New Ball</div>
            <div style={{ fontSize:12,color:"rgba(255,255,255,0.35)",marginTop:3 }}>everybody chips in · one person wins</div>
          </div>
          <div style={{ display:"flex",flexDirection:"column",alignItems:"flex-end",gap:6 }}>
            <div style={{ background:"linear-gradient(135deg,rgba(168,85,247,0.25),rgba(236,72,153,0.25))",border:"1px solid rgba(168,85,247,0.35)",borderRadius:20,padding:"6px 14px",fontSize:15,fontWeight:700 }}>
              ${pot} <span style={{ fontSize:11,fontWeight:400,opacity:0.5 }}>pot</span>
            </div>
            <button className="btn" onClick={() => signOut(db._app ? db._app.auth : require("firebase/auth").getAuth())} style={{ fontSize:11,color:"rgba(255,255,255,0.2)",background:"transparent",border:"none",cursor:"pointer",padding:0 }}
              onClick={() => signOut(require("firebase/auth").getAuth())}>
              sign out
            </button>
          </div>
        </div>

        {recentJoin && (
          <div style={{ display:"inline-flex",alignItems:"center",gap:6,background:"rgba(255,255,255,0.05)",border:"1px solid rgba(255,255,255,0.08)",borderRadius:20,padding:"4px 12px",marginBottom:16,fontSize:12,color:"rgba(255,255,255,0.5)" }}>
            <span style={{ width:6,height:6,borderRadius:"50%",background:"#34d399",display:"inline-block",boxShadow:"0 0 6px #34d399" }}/>
            👋 {recentJoin} just joined
          </div>
        )}

        <div style={{ marginBottom:14 }}>
          <div style={{ fontSize:11,color:"rgba(255,255,255,0.3)",textTransform:"uppercase",letterSpacing:"0.12em",marginBottom:10 }}>Drawing on May 1st</div>
          <div style={{ display:"flex",gap:8 }}>
            <Tick val={cd.d} label="days"/>
            <Tick val={cd.h} label="hrs"/>
            <Tick val={cd.m} label="min"/>
            <Tick val={cd.s} label="sec"/>
          </div>
        </div>

        <div style={{ display:"grid",gridTemplateColumns:"1fr 1px 1fr",background:"rgba(255,255,255,0.04)",border:"1px solid rgba(255,255,255,0.08)",borderRadius:14,padding:"14px 20px",gap:0 }}>
          <div>
            <div style={{ fontSize:11,color:"rgba(255,255,255,0.3)",textTransform:"uppercase",letterSpacing:"0.1em",marginBottom:4 }}>Your odds</div>
            <div style={{ fontFamily:"'Fraunces',serif",fontSize:34,fontWeight:700,color:"#c084fc",lineHeight:1 }}>{odds}%</div>
          </div>
          <div style={{ background:"rgba(255,255,255,0.08)" }}/>
          <div style={{ paddingLeft:20 }}>
            <div style={{ fontSize:11,color:"rgba(255,255,255,0.3)",textTransform:"uppercase",letterSpacing:"0.1em",marginBottom:4 }}>In the pool</div>
            <div style={{ fontFamily:"'Fraunces',serif",fontSize:34,fontWeight:700,color:"#fff",lineHeight:1 }}>{pot} <span style={{ fontSize:16,fontWeight:300,opacity:0.4 }}>paid</span></div>
          </div>
        </div>
      </div>

      {/* TABS */}
      <div style={{ display:"flex",background:"#0a0a0f",borderBottom:"1px solid rgba(255,255,255,0.07)",padding:"0 4px" }}>
        {[{id:"home",label:"Home"},{id:"wishes",label:"Wishes"},{id:"winners",label:"Winners"},{id:"how",label:"How it works"}].map(t=>(
          <button key={t.id} className="tab-btn" onClick={()=>setTab(t.id)} style={{ flex:1,padding:"13px 2px",color:tab===t.id?"#c084fc":"rgba(255,255,255,0.3)",fontSize:11,fontWeight:tab===t.id?700:400,borderBottom:tab===t.id?"2px solid #c084fc":"2px solid transparent",textTransform:"uppercase",letterSpacing:"0.05em" }}>
            {t.label}
          </button>
        ))}
      </div>

      {/* CONTENT */}
      <div style={{ flex:1,overflowY:"auto",padding:"20px 16px 100px" }}>

        {/* HOME */}
        {tab==="home" && (
          <div style={{ display:"flex",flexDirection:"column",gap:14,animation:"fade-up 0.3s ease" }}>

            {/* Paid status */}
            {myData && !myData.paid && (
              <div style={{ background:"rgba(251,146,60,0.08)",border:"1px solid rgba(251,146,60,0.25)",borderRadius:14,padding:"16px",display:"flex",justifyContent:"space-between",alignItems:"center" }}>
                <div>
                  <div style={{ fontSize:14,fontWeight:700,color:"#fb923c" }}>Your $1 is due</div>
                  <div style={{ fontSize:12,color:"rgba(255,255,255,0.35)",marginTop:2 }}>Pay to be eligible this month</div>
                </div>
                <button className="btn" onClick={markPaid} style={{ background:"#fb923c",color:"#fff",border:"none",borderRadius:10,padding:"10px 18px",fontSize:13,fontWeight:700,fontFamily:"inherit" }}>
                  Mark paid
                </button>
              </div>
            )}
            {myData && myData.paid && (
              <div style={{ background:"rgba(52,211,153,0.07)",border:"1px solid rgba(52,211,153,0.2)",borderRadius:14,padding:"14px 16px",display:"flex",alignItems:"center",gap:10 }}>
                <span style={{ fontSize:18 }}>✓</span>
                <div>
                  <div style={{ fontSize:14,fontWeight:600,color:"#34d399" }}>You're in this month</div>
                  <div style={{ fontSize:12,color:"rgba(255,255,255,0.3)" }}>🔥 {myData.streak}-month streak</div>
                </div>
              </div>
            )}

            {/* Who's in */}
            <div style={{ background:"rgba(255,255,255,0.03)",border:"1px solid rgba(255,255,255,0.07)",borderRadius:14,padding:"16px" }}>
              <div style={{ display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:14 }}>
                <div style={{ fontSize:13,fontWeight:600,color:"rgba(255,255,255,0.7)" }}>Who's in this month</div>
                <div style={{ fontSize:12,color:"rgba(255,255,255,0.25)" }}>{pot}/{members.length}</div>
              </div>
              <div style={{ display:"flex",flexWrap:"wrap",gap:6 }}>
                {members.map((m,i)=>(
                  <div key={m.uid} title={m.name} style={{ width:32,height:32,borderRadius:"50%",background:m.paid?`hsl(${(i*47+260)%360},55%,55%)`:"rgba(255,255,255,0.07)",display:"flex",alignItems:"center",justifyContent:"center",fontSize:9,fontWeight:700,color:m.paid?"#fff":"rgba(255,255,255,0.2)",border:m.paid?"none":"1px dashed rgba(255,255,255,0.12)",opacity:m.paid?1:0.5 }}>
                    {m.name?.slice(0,2).toUpperCase()}
                  </div>
                ))}
              </div>
            </div>

            {/* My wish */}
            <div style={{ background:"rgba(255,255,255,0.03)",border:"1px solid rgba(255,255,255,0.07)",borderRadius:14,padding:"16px" }}>
              <div style={{ fontSize:13,fontWeight:600,color:"rgba(255,255,255,0.7)",marginBottom:10 }}>What would you do with it?</div>
              <textarea
                placeholder="Be specific — it inspires others and makes your wish real."
                value={wish}
                onChange={e=>setWish(e.target.value)}
                rows={3}
                style={{ width:"100%",background:"rgba(255,255,255,0.04)",border:"1px solid rgba(255,255,255,0.09)",borderRadius:10,padding:"11px",fontSize:13,fontFamily:"inherit",resize:"none",color:"#fff" }}
              />
              <button className="btn" onClick={saveWish} style={{ marginTop:8,background:wishSaved?"rgba(52,211,153,0.15)":"rgba(255,255,255,0.07)",border:wishSaved?"1px solid #34d399":"1px solid rgba(255,255,255,0.1)",color:wishSaved?"#34d399":"rgba(255,255,255,0.6)",borderRadius:8,padding:"9px 18px",fontSize:13,fontWeight:600,fontFamily:"inherit" }}>
                {wishSaved ? "✓ Saved" : "Save wish"}
              </button>
            </div>

            {/* Invite */}
            <div style={{ background:"rgba(255,255,255,0.03)",border:"1px solid rgba(255,255,255,0.07)",borderRadius:14,padding:"16px" }}>
              <div style={{ fontSize:14,fontWeight:700,marginBottom:4 }}>Invite friends, grow the ball 🎱</div>
              <div style={{ fontSize:13,color:"rgba(255,255,255,0.35)",marginBottom:14,lineHeight:1.6 }}>
                Every person who joins adds $1 to the pot. Your odds stay the same — but the prize gets bigger. The more the merrier.
              </div>
              <button className="btn" onClick={copyInvite} style={{ width:"100%",padding:"12px",background:referCopied?"rgba(52,211,153,0.1)":"rgba(255,255,255,0.05)",border:referCopied?"1px solid #34d399":"1px solid rgba(255,255,255,0.09)",color:referCopied?"#34d399":"rgba(255,255,255,0.65)",borderRadius:10,fontSize:13,fontWeight:600,fontFamily:"inherit" }}>
                {referCopied ? "✓ Invite link copied!" : "Copy your invite link"}
              </button>
            </div>

            {/* Admin draw */}
            {isAdmin && (
              <div style={{ background:"rgba(168,85,247,0.08)",border:"1px solid rgba(168,85,247,0.25)",borderRadius:14,padding:"16px" }}>
                <div style={{ fontSize:13,fontWeight:700,color:"#c084fc",marginBottom:8 }}>⚡ Admin — Run the draw</div>
                {drawWinner ? (
                  <div style={{ textAlign:"center",animation:"bounce-in 0.5s ease" }}>
                    <div style={{ fontSize:28,marginBottom:4 }}>🎱</div>
                    <div style={{ fontFamily:"'Fraunces',serif",fontSize:22,fontWeight:700 }}>{drawWinner.name} wins!</div>
                    <div style={{ fontSize:13,color:"rgba(255,255,255,0.4)",marginTop:4 }}>${pot} awarded</div>
                    <button className="btn" onClick={()=>setDrawWinner(null)} style={{ marginTop:12,background:"rgba(255,255,255,0.06)",border:"1px solid rgba(255,255,255,0.1)",color:"rgba(255,255,255,0.5)",borderRadius:8,padding:"8px 16px",fontSize:12,fontFamily:"inherit" }}>Dismiss</button>
                  </div>
                ) : (
                  <button className="btn" onClick={runDraw} disabled={adminDrawing||paidMembers.length===0} style={{ width:"100%",padding:"13px",background:"linear-gradient(135deg,#7c3aed,#ec4899)",borderRadius:10,color:"#fff",fontSize:14,fontWeight:700,fontFamily:"inherit",opacity:paidMembers.length===0?0.4:1 }}>
                    {adminDrawing ? "Drawing..." : `Draw winner from ${paidMembers.length} members`}
                  </button>
                )}
              </div>
            )}
          </div>
        )}

        {/* WISHES */}
        {tab==="wishes" && (
          <div style={{ animation:"fade-up 0.3s ease" }}>
            <div style={{ fontSize:13,color:"rgba(255,255,255,0.3)",marginBottom:16,lineHeight:1.5 }}>What members would do with the money. Heart the ones that move you. ♥</div>
            <div style={{ display:"flex",flexDirection:"column",gap:10 }}>
              {sortedMembers.map((m,i)=>{
                const count = getLikeCount(m.uid);
                const isLiked = likes[m.uid];
                const isTop = i===0 && count>0;
                const color = `hsl(${(members.findIndex(x=>x.uid===m.uid)*47+260)%360},55%,65%)`;
                return (
                  <div key={m.uid} style={{ background:isTop?"rgba(192,132,252,0.07)":"rgba(255,255,255,0.03)",border:isTop?"1px solid rgba(192,132,252,0.25)":"1px solid rgba(255,255,255,0.07)",borderRadius:14,padding:"14px 16px",opacity:m.paid?1:0.45 }}>
                    <div style={{ display:"flex",alignItems:"center",gap:10,marginBottom: m.wish?10:0 }}>
                      <div style={{ width:36,height:36,borderRadius:"50%",background:color,display:"flex",alignItems:"center",justifyContent:"center",fontSize:11,fontWeight:700,color:"#fff",flexShrink:0 }}>
                        {m.name?.slice(0,2).toUpperCase()}
                      </div>
                      <div style={{ flex:1 }}>
                        <div style={{ display:"flex",alignItems:"center",gap:6 }}>
                          <span style={{ fontSize:14,fontWeight:600 }}>{m.name}</span>
                          {m.uid === user.uid && <span style={{ fontSize:10,color:"#c084fc" }}>you</span>}
                          {isTop && <span style={{ fontSize:10,background:"rgba(192,132,252,0.15)",color:"#c084fc",borderRadius:4,padding:"2px 6px",fontWeight:700 }}>TOP</span>}
                          {!m.paid && <span style={{ fontSize:10,color:"rgba(255,255,255,0.25)" }}>unpaid</span>}
                        </div>
                        <div style={{ fontSize:11,color:"rgba(255,255,255,0.22)" }}>🔥 {m.streak||0}-month streak</div>
                      </div>
                      <button className="btn" onClick={()=>m.uid!==user.uid&&toggleLike(m.uid)} style={{ display:"flex",flexDirection:"column",alignItems:"center",gap:2,padding:"6px 8px",borderRadius:8,background:isLiked?"rgba(244,114,182,0.12)":"rgba(255,255,255,0.04)",border:isLiked?"1px solid rgba(244,114,182,0.35)":"1px solid rgba(255,255,255,0.07)",cursor:m.uid===user.uid?"default":"pointer" }}>
                        <span style={{ fontSize:16,lineHeight:1,filter:isLiked?"none":"grayscale(1) opacity(0.4)" }}>♥</span>
                        <span style={{ fontSize:10,fontWeight:600,color:isLiked?"#f472b6":"rgba(255,255,255,0.25)" }}>{count}</span>
                      </button>
                    </div>
                    {m.wish ? (
                      <div style={{ fontSize:14,color:"rgba(255,255,255,0.65)",fontFamily:"'Fraunces',serif",fontStyle:"italic",lineHeight:1.5,paddingLeft:46 }}>
                        "{m.wish}"
                      </div>
                    ) : (
                      <div style={{ fontSize:12,color:"rgba(255,255,255,0.18)",fontStyle:"italic",paddingLeft:46 }}>No wish yet…</div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* WINNERS */}
        {tab==="winners" && <WinnersTab />}

        {/* HOW IT WORKS */}
        {tab==="how" && (
          <div style={{ animation:"fade-up 0.3s ease",display:"flex",flexDirection:"column",gap:14 }}>
            <div style={{ fontFamily:"'Fraunces',serif",fontSize:26,fontWeight:700,lineHeight:1.3,marginBottom:4 }}>
              Simple by design.<br/>
              <span style={{ fontStyle:"italic",fontWeight:300,color:"rgba(255,255,255,0.4)",fontSize:22 }}>Powerful by community.</span>
            </div>

            {[
              { step:"01", title:"Everyone chips in $1", body:"Once a month, every member throws a dollar into the pool. No more, no less." },
              { step:"02", title:"The ball gets bigger", body:"Every dollar that comes in makes the ball roll a little heavier. The more people who join, the more it's worth — that's the whole game." },
              { step:"03", title:"One person gets the new ball", body:"At the end of the month, one member is randomly selected to receive the entire pool. That's their New Ball — a fresh start, a little win, a moment that's theirs." },
              { step:"04", title:"Every dollar comes back", body:"No house cut. No fees. No catch. 100% of what goes in comes back out to a member. Always." },
            ].map((s,i)=>(
              <div key={i} style={{ background:"rgba(255,255,255,0.03)",border:"1px solid rgba(255,255,255,0.07)",borderRadius:14,padding:"18px",display:"flex",gap:14,alignItems:"flex-start" }}>
                <div style={{ fontFamily:"monospace",fontSize:11,fontWeight:500,color:"#c084fc",opacity:0.5,paddingTop:2,flexShrink:0 }}>{s.step}</div>
                <div>
                  <div style={{ fontSize:15,fontWeight:700,marginBottom:4 }}>{s.title}</div>
                  <div style={{ fontSize:13,color:"rgba(255,255,255,0.4)",lineHeight:1.65 }}>{s.body}</div>
                </div>
              </div>
            ))}

            <div style={{ background:"linear-gradient(135deg,rgba(168,85,247,0.1),rgba(236,72,153,0.07))",border:"1px solid rgba(168,85,247,0.18)",borderRadius:14,padding:"18px" }}>
              <div style={{ fontSize:15,fontWeight:700,marginBottom:6 }}>Is this legal? 🤔</div>
              <div style={{ fontSize:13,color:"rgba(255,255,255,0.4)",lineHeight:1.7 }}>
                New Ball is modeled after a ROSCA — a Rotating Savings and Credit Association. One of the world's oldest financial tools. No house, no cut, no catch. Every dollar in comes back out to a member.
              </div>
            </div>
          </div>
        )}
      </div>

      {/* BOTTOM NAV */}
      <div style={{ position:"fixed",bottom:0,left:"50%",transform:"translateX(-50%)",width:"100%",maxWidth:430,background:"rgba(10,10,15,0.96)",backdropFilter:"blur(12px)",borderTop:"1px solid rgba(255,255,255,0.07)",display:"flex",padding:"10px 0 18px" }}>
        {[{id:"home",icon:"⬡",label:"Home"},{id:"wishes",icon:"♥",label:"Wishes"},{id:"winners",icon:"◎",label:"Winners"},{id:"how",icon:"?",label:"How it works"}].map(n=>(
          <button key={n.id} onClick={()=>setTab(n.id)} style={{ flex:1,border:"none",background:"transparent",cursor:"pointer",display:"flex",flexDirection:"column",alignItems:"center",gap:3,color:tab===n.id?"#c084fc":"rgba(255,255,255,0.22)" }}>
            <span style={{ fontSize:17,lineHeight:1 }}>{n.icon}</span>
            <span style={{ fontSize:10,fontWeight:tab===n.id?700:400,textTransform:"uppercase",letterSpacing:"0.04em" }}>{n.label}</span>
          </button>
        ))}
      </div>
    </div>
  );
}

function WinnersTab() {
  const [history, setHistory] = useState([]);
  useEffect(() => {
    const q = query(collection(db, "history"), orderBy("drawnAt","desc"));
    return onSnapshot(q, snap => setHistory(snap.docs.map(d=>({id:d.id,...d.data()}))));
  },[]);

  const colors = ["#c084fc","#f472b6","#60a5fa","#34d399","#fb923c"];

  return (
    <div style={{ animation:"fade-up 0.3s ease",display:"flex",flexDirection:"column",gap:12 }}>
      <div style={{ fontSize:13,color:"rgba(255,255,255,0.3)",marginBottom:4 }}>Every dollar comes back. Here's proof.</div>
      {history.length === 0 && (
        <div style={{ textAlign:"center",padding:"40px 0",color:"rgba(255,255,255,0.2)",fontSize:14 }}>
          No draws yet — the first one's coming soon. 🎱
        </div>
      )}
      {history.map((h,i)=>(
        <div key={h.id} style={{ background:"rgba(255,255,255,0.03)",border:"1px solid rgba(255,255,255,0.07)",borderRadius:14,padding:"18px",borderLeft:`3px solid ${colors[i%colors.length]}` }}>
          <div style={{ display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:10 }}>
            <div>
              <div style={{ fontSize:11,color:"rgba(255,255,255,0.22)",marginBottom:4,textTransform:"uppercase",letterSpacing:"0.08em" }}>{h.month}</div>
              <div style={{ fontFamily:"'Fraunces',serif",fontSize:20,fontWeight:700 }}>🏆 {h.winnerName}</div>
            </div>
            <div style={{ fontFamily:"'Fraunces',serif",fontSize:30,fontWeight:700,color:colors[i%colors.length] }}>${h.amount}</div>
          </div>
          {h.winnerWish && (
            <div style={{ fontSize:13,color:"rgba(255,255,255,0.38)",fontStyle:"italic",fontFamily:"'Fraunces',serif",borderTop:"1px solid rgba(255,255,255,0.06)",paddingTop:10 }}>
              "{h.winnerWish}"
            </div>
          )}
        </div>
      ))}
      <div style={{ background:"rgba(255,255,255,0.03)",border:"1px solid rgba(255,255,255,0.07)",borderRadius:12,padding:"14px" }}>
        <div style={{ fontSize:10,color:"rgba(255,255,255,0.18)",textTransform:"uppercase",letterSpacing:"0.06em",marginBottom:4 }}>Sponsored</div>
        <div style={{ fontSize:14,fontWeight:600,color:"rgba(255,255,255,0.75)" }}>Make your winnings work harder.</div>
        <div style={{ fontSize:12,color:"rgba(255,255,255,0.3)",marginBottom:8 }}>High-yield savings with Vault Bank. Open in minutes.</div>
        <div style={{ fontSize:13,fontWeight:700,color:"#c084fc" }}>Open an account →</div>
      </div>
    </div>
  );
}
