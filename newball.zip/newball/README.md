# 🎱 New Ball

> everybody chips in · one person wins

## Deploy to Vercel in 5 minutes

### Step 1 — Upload to GitHub

1. Go to **github.com** → click the **+** → **New repository**
2. Name it `newball` → click **Create repository**
3. On your computer, open Terminal (Mac) or Command Prompt (Windows) and run:

```
cd path/to/newball-folder
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/newball.git
git push -u origin main
```

### Step 2 — Deploy on Vercel

1. Go to **vercel.com** → click **Add New Project**
2. Connect your GitHub account if prompted
3. Select your `newball` repo
4. Click **Deploy** — that's it!

Vercel will give you a URL like `newball.vercel.app`. Text that to your friends!

### Step 3 — Enable Google Sign-in in Firebase

1. Go to **console.firebase.google.com** → your project
2. Authentication → Sign-in method → Google → Enable → Save
3. Add your Vercel URL to "Authorized domains":
   - Authentication → Settings → Authorized domains → Add domain → paste your Vercel URL

### Step 4 — Set up Firestore rules

In Firebase Console → Firestore → Rules, paste this:

```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /users/{userId} {
      allow read: if request.auth != null;
      allow write: if request.auth != null && request.auth.uid == userId;
    }
    match /history/{docId} {
      allow read: if request.auth != null;
      allow write: if request.auth != null && 
        get(/databases/$(database)/documents/users/$(request.auth.uid)).data.isAdmin == true;
    }
  }
}
```

---

## You're the admin

Sign in with **emaildavedavis@gmail.com** and you'll see the admin panel on the Home tab to run the monthly draw.

## Invite link format

Share: `https://your-app.vercel.app?ref=YOUR_USER_ID`

The app automatically tracks who invited whom.
